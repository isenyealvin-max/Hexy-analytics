# Hexy Analytics

School examination management and academic analytics platform for Kenyan CBC schools.

## Stack
- Frontend: Vite + React
- Backend: Appwrite Cloud
- Hosting: Cloudflare Pages
- Code: GitHub

## Setup
1. Clone the repo
2. `npm install`
3. `npm run dev`

Appwrite config is in `src/lib/appwrite.js` (endpoint, project, database, schools collection).

## Deployment (Cloudflare Pages)
- Connect GitHub repo
- Build command: `npm run build`
- Output directory: `dist`

## Phase 1 status
- Landing, Login, Register
- Appwrite Auth
- School registration with unique code
- Basic dashboard
